// Configuration de l'application
// MODIFIEZ LES INFORMATIONS ICI

// Nom du voyageur actuel (laissez vide "" si aucun voyageur)
const GUEST_NAME = "Stephane";

// Configuration WiFi
const WIFI_SSID = "LesMouettes";           // À MODIFIER
const WIFI_PASSWORD = "LesMouettes85"; // À MODIFIER
const WIFI_SECURITY = "WPA";                 // WPA, WEP, ou nopass
